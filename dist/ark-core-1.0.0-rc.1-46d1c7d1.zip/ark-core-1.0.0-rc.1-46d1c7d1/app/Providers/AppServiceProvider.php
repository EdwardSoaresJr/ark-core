<?php

namespace App\Providers;

use App\Ark\Communications\Provisioning\ProvisionBuilder;
use App\Ark\Install\DeferredMigrationLoader;
use App\Ark\Mobile\Push\DispatchMobilePushForInboundMessage;
use App\Ark\Mobile\Push\DispatchMobilePushForOperationalEvent;
use App\Ark\Mobile\Push\NotifyMobileLifecyclePushAction;
use App\Ark\Mobile\Push\PushTransport;
use App\Ark\Mobile\Push\Transport\Firebase\FirebasePushTransport;
use App\Ark\Operations\Approvals\ApprovalEvent;
use App\Ark\Operations\Commands\OperationsCommandRegistry;
use App\Ark\Operations\Commands\RegisterCoreOperationsCommands;
use App\Ark\Operations\Communications\CommunicationsWorkspaceSignals;
use App\Ark\Operations\Communications\CoreCommunicationsWorkspaceSignals;
use App\Ark\Operations\Documents\PdfRenderer;
use App\Ark\Operations\Documents\PreferringPdfRenderer;
use App\Ark\Operations\Documents\PdfRuntimeConfigurator;
use App\Ark\Operations\Events\OperationalEvent;
use App\Ark\Operations\Learn\LearnArkProgressResolver;
use App\Ark\Operations\Messaging\Events\ConversationMessageReceived;
use App\Ark\Operations\Messaging\NotConfiguredOutboundSmsTransport;
use App\Ark\Operations\Messaging\OutboundSmsTransport;
use App\Ark\Operations\Messaging\TwilioOutboundSmsTransport;
use App\Ark\Operations\Parts\Contracts\PartsCatalogLauncher;
use App\Ark\Operations\Parts\NotConfiguredPartsCatalogLauncher;
use App\Ark\Operations\Parts\LinkedPartsQuotes;
use App\Ark\Operations\Parts\PartsTechCredentialsResolver;
use App\Ark\Operations\Parts\UnavailableLinkedPartsQuotes;
use App\Ark\Operations\Parts\PartsTechHttpClient;
use App\Ark\Operations\Parts\PlatformPartsCatalogLauncher;
use App\Ark\Operations\Recommendations\RecommendationWorkCompletionListener;
use App\Ark\Operations\RepairOrders\RepairOrderConcurrency;
use App\Ark\Operations\RepairOrders\RepairOrderReadCache;
use App\Ark\Operations\RepairOrders\Status\RepairOrderStatusCatalog;
use App\Ark\Operations\Settings\ShopDisplayTimezone;
use App\Ark\Operations\Settings\ShopIntegrationCredentials;
use App\Ark\Operations\Settings\ShopIntegrationRuntimeConfig;
use App\Ark\Operations\Settings\ShopSettingsSchema;
use App\Ark\Operations\Staff\NullStaffNavigationAugmentor;
use App\Ark\Operations\Staff\StaffNavigationAugmentor;
use App\Ark\Operations\Telephony\Contracts\TelephonyProvider;
use App\Ark\Operations\Telephony\Providers\NotConfiguredTelephonyProvider;
use App\Ark\Operations\Workboard\JobBoardLaneCatalog;
use App\Ark\Operations\Workspace\WorkspaceTabBootEnricher;
use App\Ark\Platform\Mail\ArkMailClient;
use App\Ark\Platform\Mail\PlatformAwareMailManager;
use App\Ark\Platform\Mail\PlatformMailTransport;
use App\Ark\Platform\Parts\PartsTechPlatformGateway;
use App\Ark\Platform\Provisioning\Coolify\CoolifyAdapter;
use App\Ark\Platform\Provisioning\Coolify\CoolifyClient;
use App\Ark\Platform\Provisioning\Coolify\CoolifyDeploymentMapper;
use App\Ark\Platform\Provisioning\Coolify\CoolifyExecutionStore;
use App\Ark\Platform\Provisioning\Coolify\FakeCoolifyClient;
use App\Ark\Platform\Voice\PlatformRecordingClient;
use App\Ark\Platform\VoiceTransportRuntimeConfig;
use App\Ark\Runtime\Broadcast\ReverbDeployment;
use App\Ark\Runtime\DemoInstall;
use App\Ark\Runtime\HostedRuntime;
use App\Ark\Runtime\Surfaces\PublicRootUrlConfigurator;
use App\Ark\Vehicles\Providers\NhtsaProvider;
use App\Ark\Vehicles\VehicleIntelligenceManager;
use App\Http\Middleware\ApplyShopRuntimeConfig;
use App\Models\User;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Contracts\Http\Kernel as HttpKernel;
use Illuminate\Database\Events\MigrationsEnded;
use Illuminate\Http\Request;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Mail\MailServiceProvider;
use Illuminate\Queue\Events\JobExceptionOccurred;
use Illuminate\Queue\Events\JobProcessed;
use Illuminate\Queue\Events\JobProcessing;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Tests\ParallelTestingConfiguration;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(RepairOrderReadCache::class);
        $this->app->bind(LinkedPartsQuotes::class, UnavailableLinkedPartsQuotes::class);
        $this->app->bind(CommunicationsWorkspaceSignals::class, CoreCommunicationsWorkspaceSignals::class);
        // Request-scoped so a host binding cannot leak across HTTP requests or tenants.
        $this->app->scoped(StaffNavigationAugmentor::class, NullStaffNavigationAugmentor::class);

        // Pre-DB first-run: avoid database session/cache before installer configures MySQL.
        // A hosted shop's install marker lives in tenant storage, which is not active yet.
        // Leaving the configured drivers in place keeps Redis sessions and the tenant-scoped
        // shop cache store. Do not rename that store to the generic redis store.
        if (HostedRuntime::shouldUseFileDriversBeforeInstall()) {
            config([
                'session.driver' => 'file',
                'cache.default' => 'file',
                'queue.default' => 'sync',
            ]);
        }

        $this->app->afterResolving(HttpKernel::class, function (HttpKernel $kernel): void {
            if (HostedRuntime::catalogConfigured()) {
                $kernel->prependMiddleware(ApplyShopRuntimeConfig::class);
            }
        });

        $this->app->scoped(PlatformRecordingClient::class);
        $this->app->scoped(PartsTechHttpClient::class, function ($app): PartsTechHttpClient {
            $resolver = $app->make(PartsTechCredentialsResolver::class);
            $credentials = $resolver->forUser(auth()->user());

            return new PartsTechHttpClient($credentials);
        });
        $this->app->scoped(PartsTechPlatformGateway::class);
        $this->app->scoped(ShopIntegrationCredentials::class, fn (): ShopIntegrationCredentials => ShopIntegrationCredentials::forCurrentShop());
        $this->app->bind(OutboundSmsTransport::class, function (): OutboundSmsTransport {
            $credentials = ShopIntegrationCredentials::forCurrentShop();

            if ($credentials->twilioConfigured() && filled($credentials->twilioFromNumber())) {
                return new TwilioOutboundSmsTransport($credentials);
            }

            return new NotConfiguredOutboundSmsTransport;
        });
        $this->app->bind(TelephonyProvider::class, NotConfiguredTelephonyProvider::class);
        $this->app->scoped(RepairOrderConcurrency::class);
        $this->app->scoped(RepairOrderStatusCatalog::class);
        $this->app->scoped(JobBoardLaneCatalog::class);

        $this->app->singleton(ProvisionBuilder::class, fn (): ProvisionBuilder => ProvisionBuilder::default());

        $this->app->bind(CoolifyClient::class, fn (): CoolifyClient => new FakeCoolifyClient);

        $this->app->bind(CoolifyAdapter::class, function ($app): CoolifyAdapter {
            $enabled = (bool) config('ark-platform.coolify.enabled', false);

            return new CoolifyAdapter(
                client: $app->make(CoolifyClient::class),
                mapper: $app->make(CoolifyDeploymentMapper::class),
                execution: $app->make(CoolifyExecutionStore::class),
                milestone: max(1, min(5, (int) config('ark-platform.coolify.milestone', 1))),
                applicationUuid: config('ark-platform.coolify.application_uuid'),
                enabled: $enabled,
                pollIntervalSeconds: (int) config('ark-platform.coolify.poll_interval_seconds', 2),
                pollTimeoutSeconds: (int) config('ark-platform.coolify.poll_timeout_seconds', 60),
                allowDisabledSuccess: app()->environment('testing', 'local') && ! $enabled,
            );
        });

        $this->app->bind(PartsCatalogLauncher::class, function ($app) {
            if (config('services.parts_catalog.driver') === 'platform') {
                return $app->make(PlatformPartsCatalogLauncher::class);
            }

            return $app->make(NotConfiguredPartsCatalogLauncher::class);
        });

        $this->app->bind(PdfRenderer::class, PreferringPdfRenderer::class);
        $this->app->bind(VehicleIntelligenceManager::class, fn ($app) => new VehicleIntelligenceManager(
            [$app->make(NhtsaProvider::class)],
        ));

        $this->app->bind(PushTransport::class, FirebasePushTransport::class);

        foreach (DeferredMigrationLoader::paths() as $path) {
            $this->loadMigrationsFrom($path);
        }

        $this->app->scoped(OperationsCommandRegistry::class, function ($app): OperationsCommandRegistry {
            $registry = new OperationsCommandRegistry;
            $app->make(RegisterCoreOperationsCommands::class)($registry);

            return $registry;
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RepairOrderReadCache::registerFlushListeners();
        $this->app['events']->listen(JobProcessing::class, static function (): void {
            RepairOrderReadCache::beginUnitOfWork();
        });
        $this->app['events']->listen(JobProcessed::class, static function (): void {
            RepairOrderReadCache::beginUnitOfWork();
        });
        $this->app['events']->listen(JobExceptionOccurred::class, static function (): void {
            RepairOrderReadCache::beginUnitOfWork();
        });
        $this->app['events']->listen(MigrationsEnded::class, static function (): void {
            ShopSettingsSchema::flush();
        });

        $this->app->register(MailServiceProvider::class);
        $this->app->extend('mail.manager', function ($manager, $app) {
            $custom = new PlatformAwareMailManager($app);
            $custom->extend('ark-platform', fn () => new PlatformMailTransport($app->make(ArkMailClient::class)));

            return $custom;
        });
        Mail::clearResolvedInstances();

        if ($this->app->environment('testing')) {
            ParallelTestingConfiguration::register();
        }

        $this->app->terminating(function (): void {
            RepairOrderReadCache::beginUnitOfWork();

            if ($this->app->resolved(RepairOrderConcurrency::class)) {
                $this->app->make(RepairOrderConcurrency::class)->abandonIfStillHolding();
            }
        });

        PublicRootUrlConfigurator::apply();

        if (str_starts_with((string) config('app.url'), 'https://')) {
            URL::forceScheme('https');
        }

        ResetPassword::createUrlUsing(function (User $user, string $token): string {
            $parameters = [
                'token' => $token,
                'email' => $user->getEmailForPasswordReset(),
            ];

            // Hosted SaaS: pin the link to this shop's host (request or primary domain).
            // Tokens live in the tenant DB; the host must match so a link cannot open another shop.
            if (class_exists(\Central\Support\TenantUrl::class)) {
                return \Central\Support\TenantUrl::route('password.reset', $parameters);
            }

            return URL::route('password.reset', $parameters);
        });

        PdfRuntimeConfigurator::apply();
        ShopIntegrationRuntimeConfig::apply();
        VoiceTransportRuntimeConfig::apply();
        ShopDisplayTimezone::apply();

        RateLimiter::for('portal-token-read', function (Request $request): Limit {
            return Limit::perMinute(60)->by($request->ip());
        });

        RateLimiter::for('portal-token-write', function (Request $request): Limit {
            return Limit::perMinute(20)->by($request->ip());
        });

        if (! $this->app->environment('testing') && ($warning = ReverbDeployment::hostMismatchWarning()) !== null) {
            Log::warning($warning);
        }

        View::composer('components.operations.app', function ($view): void {
            $user = auth()->user();
            $request = request();
            $learnTrainingSnooze = null;
            $canSnoozeTraining = false;

            if ($user !== null && ! DemoInstall::isDemo()) {
                $shell = app(LearnArkProgressResolver::class)
                    ->shellProjectionFor($user);

                $learnTrainingSnooze = $shell->isCurrent ? null : $shell->snoozeState;
                $canSnoozeTraining = $shell->canSnoozeTraining;
            }

            $view->with('learnTrainingSnooze', $learnTrainingSnooze);
            $view->with('canSnoozeTraining', $canSnoozeTraining);

            if (! config('ark_workspace_tabs.enabled', true)) {
                $view->with('arkWorkspaceEntity', null);

                return;
            }

            $boot = $request?->attributes->get('operations.workspace_tab_boot');

            if (! is_array($boot)) {
                $boot = app(WorkspaceTabBootEnricher::class)->forRequest($request);
            }

            $view->with('arkWorkspaceEntity', $boot);
        });

        Event::listen(MessageSending::class, function (MessageSending $event): void {
            if ($event->message->getReplyTo() !== []) {
                return;
            }

            $address = config('mail.reply_to.address');

            if (! filled($address)) {
                return;
            }

            $event->message->replyTo(
                $address,
                config('mail.reply_to.name') ?: null,
            );
        });

        Event::listen(
            ConversationMessageReceived::class,
            DispatchMobilePushForInboundMessage::class,
        );

        OperationalEvent::created(DispatchMobilePushForOperationalEvent::class);

        ApprovalEvent::created(function (ApprovalEvent $event): void {
            app(NotifyMobileLifecyclePushAction::class)->forEstimateApproved($event);
        });

        OperationalEvent::created(RecommendationWorkCompletionListener::class);
    }
}
